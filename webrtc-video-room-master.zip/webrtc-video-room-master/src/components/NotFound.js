import React from 'react';
export default () => <h1>404.. This page is not found!</h1>;
